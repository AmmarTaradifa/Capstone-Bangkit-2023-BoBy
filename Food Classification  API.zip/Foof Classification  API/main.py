from flask import Flask, render_template, request
import tensorflow as tf
import numpy as np
from PIL import Image

app = Flask(__name__)
model = tf.lite.Interpreter(model_path='foods.tflite')
model.allocate_tensors()
input_details = model.get_input_details()
output_details = model.get_output_details()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get the image from the user
    file = request.files['file']
    img = Image.open(file)
    img = img.resize((300, 300))
    img = np.array(img) / 255.0
    img = img.astype(np.float32)
    img = np.expand_dims(img, axis=0)

    # Perform the prediction
    model.set_tensor(input_details[0]['index'], img)
    model.invoke()
    output_data = model.get_tensor(output_details[0]['index'])
    predicted_class = np.argmax(output_data)

    # Map the predicted class index to class label
    class_labels = ['Apple Pie (AKG 10%-250 kkal)', 'Cheese Cake (AKG 13%-321 kkal)', 'Chicken Curry (AKG 25%-637 kkal)', 'French Fries (AKG 5%-130 kkal)', 'Fried Rice (AKG 18%-430 kkal)', 'Hamburger (AKG 10%-240 kkal)', 'Hot Dog (AKG 10%-242 kkal)', 'Ice Cream (AKG 5%-120 kkal)', 'Omelette (AKG 4%-93 kkal)', 'Pizza (AKG 15%-360 kkal)', 'Sushi (AKG 6%-146 kkal)']
    predicted_label = class_labels[predicted_class]

    # return render_template('index.html', predicted_label=predicted_label)

    return predicted_label

if __name__ == '__main__':
    app.run()
